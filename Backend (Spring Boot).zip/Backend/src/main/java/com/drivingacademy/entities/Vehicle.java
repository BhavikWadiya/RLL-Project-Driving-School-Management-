package com.drivingacademy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Vehicle {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vid;
	private String brand;
	private String model;
	private String type;
	@OneToOne(mappedBy = "vehicle")
	private Trainer trainer;
	
	
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Vehicle(String brand, String model, String type) {
		super();
		this.brand = brand;
		this.model = model;
		this.type = type;
	}
	
	public Vehicle() {}
	
	@Override
	public String toString() {
		return "Vehicle [vid=" + vid + ", brand=" + brand + ", model=" + model + ", type=" + type + "]";
	}
	
}
