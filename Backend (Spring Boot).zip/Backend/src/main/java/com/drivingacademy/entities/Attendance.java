package com.drivingacademy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Attendance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int aid;
	@ManyToOne
	private Student student;
	private String date;
	private String attendance;
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAttendance() {
		return attendance;
	}
	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}
	
	public Attendance(Student student, String date, String attendance) {
		super();
		this.student = student;
		this.date = date;
		this.attendance = attendance;
	}
	
	public Attendance() {}
	@Override
	public String toString() {
		return "Attendance [aid=" + aid + ", student=" + student + ", date=" + date + ", attendance=" + attendance
				+ "]";
	}
	
		
}
