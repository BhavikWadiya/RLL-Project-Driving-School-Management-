package com.drivingacademy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Trainer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tid;
	private String name;
	private String location;
	@OneToOne
	private Vehicle vehicle;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public Trainer(String name, String location, Vehicle vehicle) {
		super();
		this.name = name;
		this.location = location;
		this.vehicle = vehicle;
	}
	public Trainer() {}
	@Override
	public String toString() {
		return "Trainer [tid=" + tid + ", name=" + name + ", location=" + location + ", vehicle=" + vehicle + "]";
	}
	
	
}
