package com.drivingacademy.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drivingacademy.entities.Schedule;
import com.drivingacademy.services.ScheduleService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/myapi/schedule")
public class ScheduleController {

	@Autowired
	private ScheduleService scheduleService;
	
	@PostMapping("/add")
	public ResponseEntity<Schedule> addSchedule(@RequestBody Schedule sch)
	{
		Schedule schedule = scheduleService.addSchedule(sch);
		return new ResponseEntity<Schedule>(schedule, HttpStatus.ACCEPTED);
	}
	
	@PostMapping("/")
	public List<Schedule> getStudentSchedule(@RequestBody int id)
	{
		return scheduleService.getStudentSchedule(id);
	}
	
	@PostMapping("/delete")
	public ResponseEntity<String> deleteSchedule(@RequestBody int id)
	{
		scheduleService.deleteSchedule(id);
		return new ResponseEntity<String>("Schedule Deleted", HttpStatus.OK);
	}
}
