package com.drivingacademy.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivingacademy.entities.Admin;
import com.drivingacademy.entities.Student;
import com.drivingacademy.repo.StudentRepositary;

@Service
public class StudentService{

	@Autowired
	private StudentRepositary repositary;
	
	public Student saveStudent(Student student) {
		return repositary.save(student);
	}
	
	public List<Student> getStudent() {
		return repositary.findAll();
	}
	
	public void deleteStudentById(int id) {
		repositary.deleteById(id);
	}

	public Student updateStudent(int id, Student new_stud) {
		Student o_stud = null;
		if(repositary.findById(id).isPresent()) {
			
			o_stud = repositary.findById(id).get();
			o_stud = new_stud;
			repositary.save(o_stud);
			
		}
		return o_stud;
	}
	
	public Boolean verifyStudent(String name, String password)
	{
		List<Student> students = repositary.findAll();
		
		for(Student student : students)
		{
			if(student.getUsername().equals(name) && student.getPassword().equals(password)) 
			{
				return true;
			}
		}
		return false;
	}
}
