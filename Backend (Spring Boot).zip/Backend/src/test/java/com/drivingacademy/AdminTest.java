package com.drivingacademy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Admin;
import com.drivingacademy.repo.AdminRepository;


@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
public class AdminTest {
	@Autowired
	AdminRepository adminRepo;

@Test
@Order(1)
	public void saveAdminTest(){

		Admin a=new Admin();
     a.setName("Abin");
     a.setPassword("123");
      

        adminRepo.save(a);

        assertNotNull(adminRepo.findAll());
    }
	@Test
	@Order(2)
	 public void getAdminTest(){

        Admin a = adminRepo.findById(1).get();

        assertThat(a.getId()).isEqualTo(1);

    }

@Test
@Order(3)
public void adminUpdate() throws Exception {
	  Admin updateAdmin = adminRepo.findById(2).get();
	  updateAdmin.setPassword("Abin123");
     
   adminRepo.save(updateAdmin);
     
   assertThat(updateAdmin.getPassword().equals("Abin123"));
}
@Test
@Order(4)
public void admindelete() throws Exception{
     Admin a = adminRepo.findById(1).get();

     adminRepo.delete(a);



    Admin a1 = null;

     Optional<Admin> optionalAdmin = adminRepo.findById(1);

     if( optionalAdmin.isPresent()){
         a1 =  optionalAdmin.get();
     }

     assertThat(a1).isNull();
}
}
