package com.drivingacademy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Student;
import com.drivingacademy.entities.Trainer;
import com.drivingacademy.repo.StudentRepositary;

@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
public class StudentTest {
	@Autowired
	StudentRepositary sRepo;

@Test
@Order(1)
	public void saveStudentTest(){

		Student s=new Student();
        s.setAdmission_date("5/04/2022");
		s.setAge(22);
		s.setLocation("Kollam");
		s.setName("Sarath");
		s.setPassword("sa123");
		s.setTraining_type("Four wheel");
		s.setUsername("srt121");

        sRepo.save(s);

        assertNotNull(sRepo.findAll());
    }
	@Test
	@Order(2)
	 public void getStudentTest(){

        Student s = sRepo.findById(6).get();

        assertThat(s.getId()).isEqualTo(6);

    }

@Test
@Order(3)
public void studentUpdate() throws Exception {
	  Student updatestudent = sRepo.findById(12).get();
 updatestudent.setName("Abhinav");
     
   sRepo.save(updatestudent);
     
   assertThat(updatestudent.getName().equals("Abhinav"));
}
@Test
@Order(4)
public void studentdelete() throws Exception{
     Student s = sRepo.findById(15).get();

     sRepo.delete(s);



    Student s1 = null;

     Optional<Student> optionalStudent = sRepo.findById(15);

     if(optionalStudent.isPresent()){
         s1 = optionalStudent.get();
     }

     assertThat(s1).isNull();
}
}