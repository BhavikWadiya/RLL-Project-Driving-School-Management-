import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalstudentscheduleformComponent } from './localstudentscheduleform.component';

describe('LocalstudentscheduleformComponent', () => {
  let component: LocalstudentscheduleformComponent;
  let fixture: ComponentFixture<LocalstudentscheduleformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocalstudentscheduleformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalstudentscheduleformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
