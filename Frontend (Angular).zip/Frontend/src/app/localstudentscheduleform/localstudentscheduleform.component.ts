import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Schedule } from '../Schedule';
import { ScheduleService } from '../schedule.service';
import { Student } from '../Student';
import { StudentService } from '../student.service';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-localstudentscheduleform',
  templateUrl: './localstudentscheduleform.component.html',
  styleUrls: ['./localstudentscheduleform.component.css']
})
export class LocalstudentscheduleformComponent implements OnInit {

  trainers:Trainer[]
  trainers2:Trainer[]
  selectedTrainer:Trainer
  schedule:Schedule = new Schedule()
  student:Student
  selectedTrainerName:string=""
  constructor(private router:Router, private trainerService:TrainerService, private scheduleService:ScheduleService, private studentService:StudentService) { }

  ngOnInit(): void {
    this.trainerService.getTrainerByLoc("Pune").subscribe(x=>this.trainers=x);
    this.student = this.studentService.loggedinStudent
  }

  bookSchedule(schedule:Schedule, name:string)
  {
    this.trainerService.getTrainerByLoc("Pune").subscribe(x=>{this.trainers2=x
      var i
      for(i=0; i<this.trainers2.length;i++)
      {
        if(this.selectedTrainerName==this.trainers2[i].name)
        {
          this.selectedTrainer = this.trainers2[i]
          schedule.trainer = this.selectedTrainer
          schedule.student = this.student
          console.log(schedule)
          this.scheduleService.addSchedule(schedule).subscribe(
            (data)=>{console.log(data);
            }
            );
          this.router.navigateByUrl("userpage/showschedule")
        }
      }
    }); 
  }

  goBack()
  {
    this.router.navigateByUrl("userpage/showschedule")
  }

}
