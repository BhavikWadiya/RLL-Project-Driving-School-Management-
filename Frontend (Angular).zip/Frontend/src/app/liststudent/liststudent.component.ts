import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-liststudent',
  templateUrl: './liststudent.component.html',
  styleUrls: ['./liststudent.component.css']
})
export class ListstudentComponent implements OnInit {

  constructor(private router:Router, private studentService:StudentService) { }

  students:Student[]

  ngOnInit(): void {
    this.studentService.fetchStudents().subscribe(x=>this.students=x);
  }

  loadAdmitPage()
  {
    this.router.navigateByUrl("admitstudent")
  }

  loadUpdatePage(stud:Student)
  {
    this.studentService.selectedStudent = stud;
    this.router.navigateByUrl("updatestudent")
  }

  deleteStudent(id:number)
  {
    this.studentService.deleteStudent(id).subscribe(
      (data)=>{console.log(data);
        this.router.navigateByUrl("adminpage/student")
      });
      
  }

}
