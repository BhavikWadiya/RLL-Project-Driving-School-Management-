import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-updatetrainer',
  templateUrl: './updatetrainer.component.html',
  styleUrls: ['./updatetrainer.component.css']
})
export class UpdatetrainerComponent implements OnInit {

  constructor(private trainerService:TrainerService, private router:Router) { }

  trainer:Trainer
  ngOnInit(): void {
    this.trainer = this.trainerService.selectedTrainer
  }

  updateT(trainer:Trainer)
  {
    this.trainerService.updateTrainer(trainer).subscribe(
      (data)=>{console.log(data);
      }
      );
      this.router.navigateByUrl("adminpage/trainer")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/trainer")
  }

}
