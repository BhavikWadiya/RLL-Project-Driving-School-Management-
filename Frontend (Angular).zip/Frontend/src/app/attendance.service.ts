import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Attendance } from './Attendance';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  selectedAttendance:Attendance;

  addurl:string="http://localhost:8969/myapi/attendance/add"
  fetchurl:string="http://localhost:8969/myapi/attendance/"
  fetch_date_url:string="http://localhost:8969/myapi/attendance/"
  
  constructor(private http:HttpClient) { }

  addAttendance(attendance:Attendance){
     
    return this.http.post(this.addurl,attendance);

  }

  fetchAttedance():Observable<Attendance[]>
  {
     return this.http.get<Attendance[]>(this.fetchurl);

  }

  fetchByDate(date:string):Observable<Attendance[]>
  {
     return this.http.post<Attendance[]>(this.fetch_date_url,date);

  }
}