import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';
import { Vehicle } from '../Vehicle';

@Component({
  selector: 'app-listtrainer',
  templateUrl: './listtrainer.component.html',
  styleUrls: ['./listtrainer.component.css']
})
export class ListtrainerComponent implements OnInit {

  trianers:Trainer[]
  vehicles:Vehicle[]

  constructor(private router:Router, private trainerService:TrainerService) { }

  ngOnInit(): void {
    this.trainerService.getAllTrainers().subscribe(x=>this.trianers=x);
  }

  loadAddTrainer()
  {
    this.router.navigateByUrl("addtrainer")
  }

  updateTrainer(trainer:Trainer)
  {
    this.trainerService.selectedTrainer = trainer
    this.router.navigateByUrl("updatetrainer")
  }

  deleteTrainer(id:number)
  {
    this.trainerService.deleteTrainer(id).subscribe(
      (data)=>{console.log(data);
      });
      this.router.navigateByUrl("adminpage/trainer")
  }

}
