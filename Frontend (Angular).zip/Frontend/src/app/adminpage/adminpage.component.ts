import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {

  constructor(private appcomp:AppComponent, private router:Router) { }

  ngOnInit(): void {
  }

  logout()
  {
    this.appcomp.displayLoginNav=true
    this.router.navigateByUrl("/")
  }

}
