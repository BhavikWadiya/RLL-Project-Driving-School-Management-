import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vehicle } from '../Vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-listvehicle',
  templateUrl: './listvehicle.component.html',
  styleUrls: ['./listvehicle.component.css']
})
export class ListvehicleComponent implements OnInit {

  vehicles:Vehicle[]

  constructor(private router:Router, private vehicleService:VehicleService) { }

  ngOnInit(): void {
    this.vehicleService.getAllVehicles().subscribe(x=>this.vehicles=x);
  }

  updateVehiclePage(v:Vehicle)
  {
    this.vehicleService.selectedVehicle = v
    this.router.navigateByUrl("updatevehicle")
  }

  addVehicle()
  {
    this.router.navigateByUrl("addvehicle")
  }

  deleteVehicle(id:number)
  {
    this.vehicleService.deleteVehicle(id).subscribe(
      (data)=>{console.log(data);
      });
    this.router.navigateByUrl("adminpage")
  }

}
