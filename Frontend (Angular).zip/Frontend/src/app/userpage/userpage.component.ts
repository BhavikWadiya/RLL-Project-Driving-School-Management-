import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {

  allStudents:Student[]
  constructor(private studentService:StudentService, private appcomp:AppComponent, private router:Router) { }

  ngOnInit(): void {
    this.studentService.fetchStudents().subscribe(
      x=>{this.allStudents=x
        var i
        for(i=0; i<this.allStudents.length;i++)
        {
          if(this.allStudents[i].username==this.studentService.username)
          {
            this.studentService.loggedinStudent = this.allStudents[i]
          }
        }
    });
    
  }

  logout()
  {
    this.appcomp.displayLoginNav=true;
    this.router.navigateByUrl("/")
  }

}
