export class Student
{
    id:number
    name:string
    admission_date:string
    training_type:string
    location:string
    age:number
    username:string
    password:string
}