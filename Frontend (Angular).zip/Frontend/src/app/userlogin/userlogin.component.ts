import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  student:Student = new Student()
  message:string

  constructor(private router: Router, private appcomp: AppComponent,private studentService:StudentService) { }

  ngOnInit(): void {
  }

  gotoUserPage(){
    // this.router.navigate(['/userpage']);
    // this.appcomp.displayLoginNav=false;
    this.studentService.checkStudent(this.student).subscribe((res:string) => {            
      console.log(res)
      if(res=="true")
      {
        this.studentService.username = this.student.username
        this.appcomp.displayLoginNav = false
        this.router.navigate(['/userpage/tutorials']);
      }
      else{
        this.message = "Error"
      }
  
      }, )
    }
  
}
