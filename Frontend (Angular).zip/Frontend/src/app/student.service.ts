import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from './Student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  selectedStudent:Student
  username:string
  loggedinStudent:Student

  addurl:string = "http://localhost:8969/myapi/student/insert/"
  deleteurl:string = "http://localhost:8969/myapi/student/delete/"
  fetchurl:string = "http://localhost:8969/myapi/student/fetch"
  updateurl:string = "http://localhost:8969/myapi/student/update"
  loginurl:string = "http://localhost:8969/myapi/student/"

  constructor(private http:HttpClient) { }

  addStudent(student:Student)
  {
    return this.http.post(this.addurl,student)
  }

  deleteStudent(id:number)
  {
    return this.http.post<number>(this.deleteurl,id)
  }

  fetchStudents():Observable<Student[]>
  {
    return this.http.get<Student[]>(this.fetchurl)
  }

  updateStudent(stud:Student)
  {
    return this.http.post(this.updateurl,stud)
  }

  checkStudent(stud:Student)
  {
    return this.http.post(this.loginurl,stud,{ responseType: 'text'})
  }

}
