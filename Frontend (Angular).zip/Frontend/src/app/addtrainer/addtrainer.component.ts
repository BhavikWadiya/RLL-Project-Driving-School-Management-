import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';
import { Vehicle } from '../Vehicle';

@Component({
  selector: 'app-addtrainer',
  templateUrl: './addtrainer.component.html',
  styleUrls: ['./addtrainer.component.css']
})
export class AddtrainerComponent implements OnInit {

  trainer:Trainer = new Trainer()
  vehicle:Vehicle = new Vehicle()

  constructor(private trainerService:TrainerService, private router:Router) { }

  ngOnInit(): void {
  }

  saveTrainer(trainer:Trainer, vehicle:Vehicle)
  {
    trainer.vehicle = vehicle
    console.log(trainer)
    this.trainerService.addTrainer(trainer).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/trainer")
  }

}
