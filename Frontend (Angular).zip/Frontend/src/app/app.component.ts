import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from './admin.service';
import { AdminLogin } from './AdminLogin';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Driving School';
  displayLoginNav:boolean=true;
}
