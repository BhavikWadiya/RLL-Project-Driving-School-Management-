import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Attendance } from '../Attendance';
import { AttendanceService } from '../attendance.service';
import { Student } from '../Student';

@Component({
  selector: 'app-markattendance',
  templateUrl: './markattendance.component.html',
  styleUrls: ['./markattendance.component.css']
})
export class MarkattendanceComponent implements OnInit {

  attendance:Attendance = new Attendance()
  student:Student = new Student()

  constructor(private attendanceService:AttendanceService, private router:Router) { }

  ngOnInit(): void {
  }

  markAttendance(attend:Attendance,student:Student)
  {
    attend.student = student
    console.log(attend)
    this.attendanceService.addAttendance(attend).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage/attendance")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/attendance")
  }

}
