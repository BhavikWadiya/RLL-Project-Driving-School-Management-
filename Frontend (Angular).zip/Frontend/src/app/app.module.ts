import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserpageComponent } from './userpage/userpage.component';
import { AddstudentComponent } from './addstudent/addstudent.component';
import { ListstudentComponent } from './liststudent/liststudent.component';
import { AddtrainerComponent } from './addtrainer/addtrainer.component';
import { ListtrainerComponent } from './listtrainer/listtrainer.component';
import { AddvehicleComponent } from './addvehicle/addvehicle.component';
import { ListvehicleComponent } from './listvehicle/listvehicle.component';
import { MarkattendanceComponent } from './markattendance/markattendance.component';
import { ShowattendanceComponent } from './showattendance/showattendance.component';
import { TutorialsComponent } from './tutorials/tutorials.component';
import { LocalstudentscheduleformComponent } from './localstudentscheduleform/localstudentscheduleform.component';
import { RemotestudentscheduleformComponent } from './remotestudentscheduleform/remotestudentscheduleform.component';
import { ShowscheduleComponent } from './showschedule/showschedule.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminLogin } from './AdminLogin';
import { UpdatepageComponent } from './updatepage/updatepage.component';
import { UpdatetrainerComponent } from './updatetrainer/updatetrainer.component';
import { UpdatevehicleComponent } from './updatevehicle/updatevehicle.component';
import { RemoteformComponent } from './remoteform/remoteform.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminloginComponent,
    AdminpageComponent,
    UserloginComponent,
    UserpageComponent,
    AddstudentComponent,
    ListstudentComponent,
    AddtrainerComponent,
    ListtrainerComponent,
    AddvehicleComponent,
    ListvehicleComponent,
    MarkattendanceComponent,
    ShowattendanceComponent,
    TutorialsComponent,
    LocalstudentscheduleformComponent,
    RemotestudentscheduleformComponent,
    ShowscheduleComponent,
    UpdatepageComponent,
    UpdatetrainerComponent,
    UpdatevehicleComponent,
    RemoteformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AdminLogin],
  bootstrap: [AppComponent]
})
export class AppModule { }
