import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemotestudentscheduleformComponent } from './remotestudentscheduleform.component';

describe('RemotestudentscheduleformComponent', () => {
  let component: RemotestudentscheduleformComponent;
  let fixture: ComponentFixture<RemotestudentscheduleformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RemotestudentscheduleformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemotestudentscheduleformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
