export class AdminLogin{
    id:number
    name:string
    password:string
    
}