import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vehicle } from '../Vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-addvehicle',
  templateUrl: './addvehicle.component.html',
  styleUrls: ['./addvehicle.component.css']
})
export class AddvehicleComponent implements OnInit {

  constructor(private router:Router, private vechileServie:VehicleService) { }

  vehicle:Vehicle = new Vehicle

  options = [
    {name:'2 Wheeler', value:'2 Wheeler', checked:"false"},
    {name:'4 Wheeler', value:'4 Wheeler', checked:"false"}
  ]
  myRadio:string=""

  ngOnInit(): void {
  }

  saveVehicle(v:Vehicle)
  {
    var i;
    for(i=0; i<this.options.length; i++)
    {
      if(this.options[i].checked==this.options[i].name)
      {
        this.myRadio=this.options[i].value
        break;
      }
    }
    v.type = this.myRadio
    this.vechileServie.addvehicle(v).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage/vehicle")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/vehicle")
  }

}
