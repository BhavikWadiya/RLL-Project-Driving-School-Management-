export class Vehicle
{
    vid:number
    brand:string
    model:string
    type:string
}